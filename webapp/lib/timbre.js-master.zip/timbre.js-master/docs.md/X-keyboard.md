T("keyboard")
=============
{kr} Tracking Keyboard Event

_* Browser Only_

<script src="/timbre.js/src/extras/keyboard.js"></script>
