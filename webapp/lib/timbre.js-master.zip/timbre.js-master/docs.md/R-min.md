T("min")
========
{arkr} Output the minimum signal

## Description ##
en: `T("min")` outputs a signal which is the minimum.
ja: `T("min")` はそれぞれのインプットの信号の最小値を出力します。

## Source ##
https://github.com/mohayonao/timbre.js/blob/master/src/objects/min.js
