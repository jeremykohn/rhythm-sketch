T("/")
======
{krar}{stereo} Divide signals

## Description ##
en: `T("/")`  is a signal divide-operator that outputs a signal.
ja: `T("/")` はそれぞれのインプットの信号を乗算して出力します。

## Source ##
https://github.com/mohayonao/timbre.js/blob/master/src/objects/div.js
