T(Array)
===========
{kr} ArrayWrapper

## Description ##
en: `T(Array)` contains an array.
ja: 配列を格納します。

*仕様検討中*
