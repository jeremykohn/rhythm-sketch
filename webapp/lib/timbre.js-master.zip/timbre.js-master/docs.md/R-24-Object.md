T(Object)
===========
{kr} ObjectWrapper

## Description ##
en: `T(Object)` contains an object.
ja: オブジェクトを格納します。

*仕様検討中*
