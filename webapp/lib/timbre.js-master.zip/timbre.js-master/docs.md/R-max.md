T("max")
========
{arkr} Output the maximum signal

## Description ##
en: `T("max")` outputs a signal which is the maximum.
ja: `T("max")` はそれぞれのインプットの信号の最大値を出力します。

## Source ##
https://github.com/mohayonao/timbre.js/blob/master/src/objects/max.js
