T("-")
======
{krar}{stereo} Signal subtraction

## Description ##
en: `T("-")`  is a signal minus-operator that outputs a signal.
ja: `T("-")` はそれぞれのインプットの信号を減算して出力します。

## Source ##
https://github.com/mohayonao/timbre.js/blob/master/src/objects/subtract.js
